<?php
header("location:https://www.truist.com/");
?>